<?php
require_once("../core/conex.php");
require_once("../core/fbasic.php");
class tagsModel extends Conex{
	//--Metodo maximo_id_marca
	public function maximo_id_tags(){
		$sql = "SELECT MAX(id) FROM tags";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para verificar si existe un tag
	public function consultar_existe_tags2($id){
		$sql = "SELECT count(*) FROM tags where id='".$id."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para verificar si existe un tag con nombre
	public function consultar_existe_tags($descripcion){
		$sql = "SELECT count(*) FROM tags where descripcion='".$descripcion."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//---Metodo para consultar tags
	public function consultar_tags($idioma){
		if($idioma!=""){
			$where= " AND id_idioma='".$idioma."'";
		}else{
			$where= "";
		}
		$sql = "SELECT a.id,a.descripcion, a.id_idioma,a.estatus, b.descripcion FROM tags a INNER JOIN idioma b ON a.id_idioma= b.id   where 1=1 ".$where." order by a.id";
		//return $sql;
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para consultar tags segun blog
	public function consultar_tag_blog($blogs){
		$sql = "SELECT a.id, a.descripcion FROM tags a INNER JOIN tags_blog b ON a.id=b.id_tags WHERE b.id_blog='".$blogs."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}	
	//--
	//Metodo para modificar el estatus del tag
	public function modificar_tags_estatus($id,$estatus){
		$sql="UPDATE tags
				 SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	//--Metodo para modificar un tag
	public function modificar_tags($datos){

		$sql="UPDATE 
					tags
				SET		
					descripcion='".sanar_cadena($datos["descripcion"])."',
					id_idioma = '".$datos["id_idioma"]."',
					estatus = '".$datos["estatus"]."'
			  WHERE
			  		tags.id='".$datos["id"]."'";
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//--Metodo para registrar tags
	public function registrar_tags($datos){
	
		$sql="INSERT INTO tags
						(
							descripcion,
							id_idioma,
							estatus
						) 
			   VALUES (
			   			'".sanar_cadena($datos["descripcion"])."',
			   			'".$datos["id_idioma"]."',
			   			'0'
			   );";
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;

	}
}	
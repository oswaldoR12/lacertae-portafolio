<?php
require_once("../core/conex.php");
class categoriasModel extends Conex{
	private $rs;
	//--Metodo constructor...
	public function __construct(){
	}
	//--Consulta los datos de las categorias
	public function consultar_categorias($id){
		$where = "WHERE 1=1 ";
		if($id!=""){
			$where.= " AND a.id='".$id."'";
		}

		$sql = "SELECT a.id, a.descripcion, a.estatus FROM categorias a ".$where." order by a.id DESC;";
		//return $sql;
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;			
	}
	//--Metodo para registrar categorias
	public function registrar_categorias($datos){
	
		$sql="INSERT INTO categorias
						(
							descripcion,
							estatus
						) 
			   VALUES (
			   			'".sanar_cadena($datos["descripcion"])."',
			   			'0'
			   );";
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//--Metodo para verificar si existe una categorias según su id
	public function consultar_existe_categorias2($id){
		$sql = "SELECT count(*) FROM categorias where id='".$id."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para verificar si existe una categorias según su nombre
	public function consultar_existe_categorias($nombre_categoria){
		$sql = "SELECT count(*) FROM categorias where descripcion='".$nombre_categoria."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo maximo_id_categorias
	public function maximo_id_categorias(){
		$sql = "SELECT MAX(id) FROM categorias";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//Metodo para modificar el estatus de la categoria
	public function modificar_categorias_estatus($id,$estatus){
		$sql="UPDATE categorias
				 SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	//Metodo para modificar la categorias
	public function modificar_categorias($datos){

		$sql="UPDATE 
					 categorias
				SET		
					descripcion='".sanar_cadena($datos["descripcion"])."',
					estatus = '".$datos["estatus"]."'
			  WHERE
			  		categorias.id='".$datos["id"]."'";
		//return $sql;	  		
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}	
	//---
}	
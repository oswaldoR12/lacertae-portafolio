<?php
require_once("../core/conex.php");
require_once("../core/fbasic.php");
session_start();

class blogModel extends Conex{
	//--Metodo maximo_id_blog
	public function maximo_id_blog(){
		$sql = "SELECT MAX(id) FROM blog";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para definir si existe un blog con el mismo titulo
	public function consultar_existe($titulo,$id_idioma){
		$sql = "SELECT count(*) FROM blog WHERE titulo='".$titulo."' AND id_idioma='".$id_idioma."'";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--Metodo para definir si existe un blog con ese id
	public function consultar_existe2($id){
		$sql = "SELECT count(*) FROM blog WHERE id='".$id."'";
	//	return $sql;
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--Metodo para definir si existe un blog con ese id
	public function consultar_existe_otro($titulo,$id,$id_idioma){
		$sql = "SELECT count(*) FROM blog WHERE titulo='".$titulo."' AND id_idioma='".$id_idioma."' AND id!='".$id."'";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--Metodo para registrar blog
	public function registrar_blog($datos){
		list($dia,$mes,$ayo) = explode("/",$datos["fecha_publicacion"]);
		$id_usuario = $_SESSION['id'];
		$super_fecha = $ayo."-".$mes."-".$dia;
		$titulo_min = strtolower(normaliza($datos["titulo"]));
		$slug_blog = str_replace(" ","-",$titulo_min);
		$slug_blog = preg_replace("/[^a-zA-Z0-9_-]+/", "", $slug_blog);
		//--Registro el blog
		$sql = "INSERT INTO 
					blog
				(
					titulo,
					descripcion,
					id_idioma,
					fecha_publicacion,
					archivo, 
					estatus,
					slug,
					id_imagen,
					id_usuario) 
				VALUES 
				('".$datos["titulo"]."',
				 '".sanar_cadena($datos["descripcion"])."',
				 '".$datos["id_idioma"]."',
				 '".$super_fecha."',
				 '',
				 '0',
				 '".$slug_blog."',
				 '".$datos["id_imagen"]."',
				 '".$id_usuario."')";
		//return $sql;	 
		$this->rs = $this->procesarQuery2($sql);
		//return $this->rs;		
		//--Registro tags
		$id_blog = $this->maximo_id_blog();
		foreach ($datos["tags"] as $tags) {
			//---
			$sql_tags = "INSERT INTO
									tags_blog
							(
								id_tags,
								id_blog)
						VALUES
							(
								'".$tags->id."',
								'".$id_blog[0][0]."'								
							)";
			//---
			//return $sql_tags;
			$this->rs2 = $this->procesarQuery2($sql_tags);				
		}
		return $this->rs2;
	}
	//------------------------------------------------------------
	public function modificar_blog($datos){
		list($dia,$mes,$ayo) = explode("/",$datos["fecha_publicacion"]);
		$id_usuario = $_SESSION['id'];
		$super_fecha = $ayo."-".$mes."-".$dia;
		$titulo_min = strtolower(normaliza($datos["titulo"]));
		$slug_blog = str_replace(" ","-",$titulo_min);
		$slug_blog = preg_replace("/[^a-zA-Z0-9_-]+/", "", $slug_blog);
		$sql = "UPDATE 
					blog
				SET 
					titulo='".$datos["titulo"]."',
					descripcion ='".$datos["descripcion"]."',
					fecha_publicacion= '".$datos["fecha_publicacion"]."',
					estatus= '".$datos["estatus"]."',
					slug = '".$slug_blog."',
					id_imagen = '".$datos["id_imagen"]."',
					id_usuario = '".$id_usuario."'
				WHERE
					id = '".$datos["id"]."'";
		$this->rs = $this->procesarQuery2($sql);
		//ELimino los tags relacionados y vuelvo a ingresarlos..
		$sql_eliminar  = "DELETE FROM tags_blog WHERE id_blog ='".$datos["id"]."'";
		$this->rs2 = $this->procesarQuery2($sql_eliminar);
		//Inserto de nuevo los tags...
		foreach ($datos["tags"] as $tags) {
			//---
			$sql_tags = "INSERT INTO
									 tags_blog
							(
								id_tags,
								id_blog )
						 VALUES
							(
								'".$tags->id."',
								'".$datos["id"]."'								
							)";
			//---
			//die($sql_tags);
			//return $sql_tags;
			$this->rs2 = $this->procesarQuery2($sql_tags);				
		}
		//--
		return $this->rs2;
	}
	//-------------------------------------------------------------
	public function modificar_archivo_blog($path,$id_blog){
		$sql_blog = "UPDATE
							 blog
					 SET 
							 archivo='".$path."' 
					 WHERE 
							id='".$id_blog."'";
		//return $sql_blog;					
		$this->rs = $this->procesarQuery2($sql_blog);
		return $this->rs;					
	}
	//-------------------------------------------------------------
	//-Metodo para consultar blogs
	//--Consulta los datos de doctores
	public function consultar_blog(){
		$sql = "SELECT 
						a.id, 
						a.id_imagen,
						a.archivo,
						a.descripcion,
						a.estatus,
						a.fecha_publicacion,
						a.titulo,
						a.id_usuario,
						d.nombres_apellidos,
						a.slug,
						a.id_idioma,
						e.descripcion,
						b.ruta,
						a.id_usuario
				FROM 
						blog a
				INNER JOIN
						galeria b
				ON 
						b.id = a.id_imagen
				INNER JOIN
						usuarios c
				ON 
						c.id = a.id_usuario
				INNER JOIN 
						personas d
				ON 
						d.id=c.id_persona
				INNER JOIN 
						idioma e
				ON 
						e.id = a.id_idioma										
				order by 
						a.id DESC";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//-------------------------------------------------------------
	//
	public function modificar_blog_estatus($id,$estatus){
		$sql="UPDATE blog
				 SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//-------------------------------------------------------------
}	
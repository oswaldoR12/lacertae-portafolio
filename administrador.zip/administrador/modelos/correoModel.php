<?php
require_once("../core/helpers/class.phpmailer.php");
require_once("../core/helpers/class.smtp.php");
class correoModel
{
	//Metodo para realizar el envío del correo
	public function enviar_correo($usuario,$destinatario,$mensaje,$titulo)
	{
		//----------------------------------------------------------------
		$mensaje = utf8_decode($mensaje);
		$arreglo_mensaje = array();
		$exp_dest  = explode("|",$destinatario);
		$mail = new PHPMailer();
		$body = $mensaje;
		$mail->IsSMTP(); 
		//. rtrim(dirname($_SERVER['PHP_SELF']), '/\\')			                      
		// la dirección del servidor, p. ej.: smtp.servidor.com
		$mail->Host = "smtp.ipage.com";
		// dirección remitente, p. ej.: no-responder@miempresa.com
		//$mail->From = "esaica.cacao.vzla@gmail.com";
		$mail->From = $usuario;
		// nombre remitente, p. ej.: "Servicio de envío automático"
		$mail->FromName = "webmaster-tumedico-online";
		// asunto y cuerpo alternativo del mensaje
		$mail->Subject = utf8_decode("Registro de Cita");
		$mail->AltBody = $mensaje; 
		// si el cuerpo del mensaje es HTML
		$mail->MsgHTML($body);
		// podemos hacer varios AddAdress
		for($i=0;$i<count($exp_dest);$i++){
		    $mail->AddAddress($exp_dest[$i]);
		}
		// si el SMTP necesita autenticación
		$mail->SMTPAuth = true;
		// credenciales usuario
		//$mail->Username = "esaica.cacao.vzla@gmail.com";
		$mail->Username = "drmv@tumedico-online.com";
		$mail->Password = "Administrador.181931"; 
		if(!$mail->Send()) 
		{
			return "Error enviando: " . $mail->ErrorInfo."---".$mail->Password;
			return 0;
		}else
		{
			return 1;
		}

		//-------------------------------------------------------------
	}
	//Metodo para ajustar cuadros de contenido que seran enviados por medio del correo
	public function crear_cuadro($titulo,$encabezado,$arreglo_datos,$nombre_paciente){
		$vector_fecha = explode("-", $arreglo_datos["fecha"]);
		$super_fecha = $vector_fecha[2]."/".$vector_fecha[1]."/".$vector_fecha[0]." ".$arreglo_datos["hora"];
		/*$estructura_mensaje="<div>
									<div style='padding:1%;width:95%;height:auto;background-color:#006063;color:#fff;font-weight:bold;font-size:14px;'>".$encabezado."</div>
									<div style='width: 94.7%;height:auto;background-color:#fff;border-style:solid;border-color:#16a085;padding: 1%;'>	
										<div style='color:#000;font-size:32px;''>Ticket#".$nticket.":</div></br>
										<div style='color:#000;font-size:14px;'>".$descripcion_ticket."</div>
									</div>
									<div style='padding:1%;width:95%;height:auto;background-color:#006063;color:#fff;font-weight:bold;font-size:14px;'>Mensaje enviado a trav&eacute;s de Sistema de Helpdesk, por favor ingrese al sistema para verificar estos datos. </div>
							</div>";*/

		$estructura_mensaje = "<div stle='margin-top:10px;'>
								<div style='padding:1%;width:95%;height:auto;background-color:#fff;color:#000;font-weight:bold;font-size:14pt;'>
									<style='width:3%;'>Su cita ha sido agendada</div>
									<div style='padding:1%;''>
										<div style='padding1%;width:97%;height:auto;background-color:#fff;color:#000;font-weight:bold;font-size:12pt;'>".$encabezado."</div>
										<div style='margin-top:5px;;padding1%;width:95%;height:auto;background-color:#fff;color:#000;font-size:12;'>
											<div><label style='font-weight:bold;'>Paciente: </label>".$nombre_paciente."</div>
											<div>
												<p><label style='font-weight:bold;'> Doctor: </label>".$arreglo_datos["nombre_doctor"]."</p>
												<p><label style='font-weight:bold;'> Especialidad: </label>".$arreglo_datos["nombre_especialidad"]."</p>
												<p><label style='font-weight:bold;'> Fecha y hora de la cita: </label>".$super_fecha."</p>
											</div>
										</div>
										<div style='clear:both'></div>
									</div>
									<div style='padding:1%;width:95%;height:auto;background-color:#fff;color:#000;font-size:14pt;'>Ingrese en www.tumedico-online.com para verificar estos datos</div>
								</div>";												
		//$estructura_mensaje ="Esto es una prueba de correo".$arreglo_datos["nombres_contacto"]." ".$arreglo_datos["apellidos_contacto"];
		return $estructura_mensaje;					
	}
}
?>
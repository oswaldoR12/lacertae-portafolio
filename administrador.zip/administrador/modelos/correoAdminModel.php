<?php
require_once("../core/conex.php");
session_start();

class correoAdminModel extends Conex{
	private $rs;
	private $rs2;
	//--Metodo constructor...
	public function __construct(){
	}
	//---

	//Metodo que sirve para definir si existe el correo
	public function existe_correo($correo,$opcion,$id_idioma){
		$where =  " WHERE 1=1 ";
		if($opcion=="1"){
			$where.= " AND a.correo = '".$correo."'";
		}else if($opcion=="2"){
			$where.= " AND a.id = '".$correo."'";
		}
		if($id_idioma){ 
			$where.= " AND a.id_idioma='".$id_idioma."'";
		}
		$sql = "SELECT COUNT(*) FROM correos a ".$where.";";
		//return $sql;
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//Metodo que retorna el maximo id del correo
	public function maximo_id_correo(){
		$sql = "SELECT MAX(id) FROM correos";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	//Metodo para registrar correo
	public function registrar_correo($datos){
		$sql="INSERT INTO correos
			  (
					titulo,
					correo,
					estatus,
					id_idioma
			  ) 
			  VALUES (
			   			'".$datos["titulo"]."',
			   			'".$datos["correo"]."',
			   			'0',
			   			'".$datos["id_idioma"]."'   			
			  )";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;	
	}
	//Metodo para consultar correo
	public function consultar_correos(){
		$sql = "SELECT 
					a.id,
					a.titulo,
					a.correo,
					a.estatus,
					a.id_idioma,
					b.descripcion
				FROM 
					correos a
				INNER JOIN 
					idioma b
				ON 
					a.id_idioma = b.id
				order by
					a.posicion	
				";
		//return $sql;			
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//Metodo para consultar correo
	public function consultar_correos_filtros($idioma){
		$where=" WHERE 1=1";
		if($idioma){
			$where.=" AND a.id_idioma='".$idioma."' AND estatus='1' ";
		}
		$sql = "SELECT 
					a.id,
					a.titulo,
					a.correo,
					a.estatus,
					a.id_idioma,
					b.descripcion
				FROM 
					correos a
				INNER JOIN 
					idioma b
				ON 
					a.id_idioma = b.id
				".$where."	
				order by
					a.posicion	
				";
		//return $sql;			
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//Metodo para modificar el estatus del correo
	public function modificar_correo_estatus($id,$estatus){
		
		$sql="UPDATE correos 
					SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		//return $sql;	  		
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	//Metodo para modificar correos
	public function modificar_correo($datos){
		
		$sql="UPDATE correos 
					SET 
						titulo = '".$datos["titulo"]."',
			   			correo = '".$datos["correo"]."',
						estatus = '".$datos["estatus"]."',
						id_idioma = '".$datos["id_idioma"]."'
			  WHERE 
			  		id='".$datos["id"]."'";
		//return $sql;	  		
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	public function existe_otro_correo($id,$correo,$idioma){
		$where = "WHERE 1=1 ";
		$where.= " AND a.correo = '".$correo."'";
		$where.= " AND a.id != '".$id."'";
		$where.= " AND a.id_idioma = '".$idioma."'";
		$sql = "SELECT COUNT(*) FROM correos a ".$where.";";
		//return $sql;
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--
	public function modificar_posicion_correo($id,$posicion){
		$sql = "UPDATE
						correos
				SET 
						posicion='".$posicion."'
				WHERE
						id='".$id."'";
		//return $sql;				
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
}	
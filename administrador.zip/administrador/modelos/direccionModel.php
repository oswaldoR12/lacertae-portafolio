<?php
require_once("../core/conex.php");
session_start();

class direccionModel extends Conex{
	private $rs;
	private $rs2;
	//--Metodo constructor...
	public function __construct(){
	}
	//---
	public function maximo_id_direccion(){
		$sql = "SELECT MAX(id) FROM direcciones";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function existe_telefono_direccion($id_direccion,$telefono){
		$sql = "SELECT 
						count(*)
				FROM 
						telefonos a	
				WHERE 
						id_direccion='".$id_direccion."'
				AND
						telefono='".$telefono."'";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function existe_direccion($id){
		$sql = "SELECT 
						count(*)
				FROM 
						direcciones 
				WHERE
						id='".$id."'		
				";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function consultar_direcciones(){
		$sql = "SELECT 
						a.id,
						a.descripcion,
						a.estatus,
						a.id_idioma,
						b.descripcion,
						a.titulo
				FROM 
						direcciones a
				INNER JOIN 
						idioma b 
				ON 
						b.id = a.id_idioma

				order by a.id DESC		
				";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function consultar_telefonos($id_direccion){
		$sql = "SELECT 
						telefono
				FROM 
						telefonos a
				WHERE 
						id_direccion='".$id_direccion."'";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function registrar_direccion($datos){
		$sql="INSERT INTO direcciones
			  (
					descripcion,
					estatus,
					id_idioma,
					titulo
			  ) 
			  VALUES (
			   			'".$datos["descripcion"]."',
			   			'0',
			   			'".$datos["id_idioma"]."',
			   			'".$datos["titulo"]."'
			  )";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	public function registrar_telefono($id_direccion,$telefono){
		$sql="INSERT INTO telefonos
			  (
					id_direccion,
					telefono
			  ) 
			  VALUES (
			   			'".$id_direccion."',
			   			'".$telefono."'   			
			  )";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}

	//---
	public function modificar_direccion_estatus($id,$estatus){
		$sql="UPDATE direcciones 
					SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		//return $sql;	  		
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;	  		
	}
	//---
	public function modificar_direccion($arreglo_datos){
		$sql="UPDATE
				 direcciones
			  SET 	
			  		descripcion='".$arreglo_datos["descripcion"]."',
					estatus = '".$arreglo_datos["estatus"]."',
					id_idioma = '".$arreglo_datos["id_idioma"]."',
					titulo = '".$arreglo_datos["titulo"]."'
			   WHERE
			   		id='".$arreglo_datos["id"]."'";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	public function eliminar_telefonos($id_direccion){
		$sql="DELETE
			  	FROM 	 
				 telefonos
			  WHERE
			   	 id_direccion='".$id_direccion."'";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---------------------Bloque de mapas
	public function maximo_id_mapas(){
		$sql = "SELECT MAX(id) FROM direccion_mapas";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--
	public function existe_mapa($id){
		$sql = "SELECT 
						count(*)
				FROM 
						direccion_mapas 
				WHERE
						id='".$id."'		
				";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function consultar_direcciones_mapas($id_direccion){
		$sql = "SELECT 
						id,
						latitud,
						longitud
				FROM 
						direccion_mapas
				WHERE 
						id_direccion='".$id_direccion."'";
		//return $sql;				
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;				
	}
	//---
	public function registrar_mapas($datos){
		$sql="INSERT INTO direccion_mapas
			  (
					id_direccion,
					latitud,
					longitud			  
			  ) 
			  VALUES (
			   			'".$datos["id"]."',
			   			'".$datos["latitud"]."',
			   			'".$datos["longitud"]."'
			  )";
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	public function modificar_mapas($datos){
		$sql="UPDATE
					 direccion_mapas
			  SET 
					id_direccion = '".$datos["id"]."',
					latitud  ='".$datos["latitud"]."',
					longitud = '".$datos["longitud"]."'			  
			WHERE
					id='".$datos["id_mapa"]."'	
			";
		//return $sql;	
		// Ejecuto el query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//--
	public function consultar_direcciones_filtro($datos){
		$sql = "SELECT 
						a.id,
						a.descripcion,
						a.estatus,
						a.id_idioma,
						b.descripcion,
						a.titulo
				FROM 
						direcciones a
				INNER JOIN 
						idioma b 
				ON 
						b.id = a.id_idioma
				WHERE
						a.id_idioma = '".$datos["id_idioma"]."'
				AND
						a.estatus='1'
				order by a.posicion";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//---
	public function modificar_posicion_direccion($id,$posicion){
		$sql = "UPDATE
						direcciones
				SET 
						posicion='".$posicion."'
				WHERE
						id='".$id."'";
		//return $sql;				
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
}	
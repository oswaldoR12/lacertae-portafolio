<?php
require_once("../core/conex.php");
class inicioModel extends Conex{
	private $rs;
	//--Metodo constructor...
	public function __construct(){
	}
	//--Metodo para el inicio de sesion
	public function iniciar_sesion($login,$clave){
		$sql = "SELECT 
					count(*)
				FROM 
					usuarios
				WHERE
					  login='".$login."'
				AND 
					clave=sha1('".$clave."')
				AND 
					estatus=1";

		$this->rs = $this->procesarQuery($sql);
		return $this->rs;
	}
	//--MEtodo para obtener datos del usuario
	public function obtener_datos_us($login){
		$sql = "SELECT 
					a.id,
					a.login,
					a.id as id_persona,
					d.nombres_apellidos
				FROM 
					usuarios a
				INNER JOIN
					personas d
				ON 
					d.id = a.id_persona					
				WHERE
					a.login='".$login."';";
		$this->rs = $this->procesarQuery($sql);
		return $this->rs;	
	}
	//--
}	
<?php
require_once("../core/conex.php");
require_once("../core/fbasic.php");
class categoriasalbumModel extends Conex{
	//--Metodo maximo_id_categorias
	public function maximo_id_categorias(){
		$sql = "SELECT MAX(id) FROM categorias";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para verificar si existe una categorias según su id
	public function consultar_existe_categorias2($id){
		$sql = "SELECT count(*) FROM categorias where id='".$id."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//--Metodo para verificar si existe una categorias según su nombre
	public function consultar_existe_categorias($nombre_categoria){
		$sql = "SELECT count(*) FROM categorias where nombre_categoria='".$nombre_categoria."'";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	//---Metodo para consultar categorias
	public function consultar_categorias(){
		$sql = "SELECT a.id,a.descripcion, a.id_idioma,a.estatus, b.descripcion FROM categorias a INNER JOIN idioma b ON a.id_idioma= b.id order by a.id";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	
	//--
	//Metodo para modificar el estatus de la categorias
	public function modificar_categorias_estatus($id,$estatus){
		$sql="UPDATE categorias
				 SET 
						estatus = '".$estatus."'
			  WHERE 
			  		id='".$id."'";
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//---
	//--Metodo para modificar una categorias
	public function modificar_categorias($datos){

		$sql="UPDATE 
					 categorias
				SET		
					descripcion='".sanar_cadena($datos["descripcion"])."',
					id_idioma = '".$datos["id_idioma"]."',
					estatus = '".$datos["estatus"]."'
			  WHERE
			  		categorias.id='".$datos["id"]."'";
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		if($this->rs==1){
			//--
			//Elimino todos las imagenes asociadas a esa categorias
			$sql_delete = "DELETE FROM galeria_categorias WHERE id_categorias='".$datos["id"]."'";
			$this->rs_delete = $this->procesarQuery2($sql_delete);

			//Consulto el maximo id de la categorias
			$arreglo_soportes_id = array();
			$arreglo_soportes_id = $datos["id_soportes_categorias"];
			$sql_soportes = "";
			for($i=0;$i<count($arreglo_soportes_id);$i++){
				$sql_soportes=" INSERT INTO galeria_categorias
									(id_categorias,id_galeria)
								VALUES
									('".$datos["id"]."','".$arreglo_soportes_id[$i]."'); ";

				$this->rs2 = $this->procesarQuery2($sql_soportes);

			//--					
			}
			//--
		}
		return $this->rs;
	}
	//--Metodo para registrar doctores
	public function registrar_categorias($datos){
	
		$sql="INSERT INTO categorias
						(
							nombre_categoria,
							estatus
						) 
			   VALUES (
			   			'".sanar_cadena($datos["descripcion"])."',
			   			'0'
			   );";
		return($sql);	   
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;
	}
	//--
}	
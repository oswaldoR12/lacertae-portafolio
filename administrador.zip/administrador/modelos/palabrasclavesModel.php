<?php
require_once("../core/conex.php");
require_once("../core/fbasic.php");
class palabrasclavesModel extends Conex{
	//--Metodo maximo_id_marca
	public function maximo_id_palabras_claves(){
		$sql = "SELECT MAX(id) FROM palabras_claves";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	
	//---Metodo para consultar palabras claves
	public function consultar_palabras_claves(){
		$sql = "SELECT a.id,a.descripcion FROM palabras_claves a order by a.id";
		$this->rs3 = $this->procesarQuery($sql);
		return $this->rs3;
	}
	
	//--Metodo para modificar una marca
	public function modificar_palabras_claves($descripcion){
		//--
		//Elimino todos las imagenes asociadas a esa marca
		$sql_delete = "DELETE FROM palabras_claves ";
		$this->rs_delete = $this->procesarQuery2($sql_delete);
		$arreglo_palabras = explode(",", $descripcion);
		foreach ($arreglo_palabras as $valor) {
				//--
				if($valor!=""){
					$sql="INSERT INTO palabras_claves
						(
							descripcion						) 
					   VALUES (
					   			'".sanar_cadena($valor)."'
					   );";
					// Ejecuto el primer query
					$this->rs = $this->procesarQuery2($sql);
				}
				//--
		}					
		return 1;
	}
	//--Metodo para registrar doctores
	public function registrar_palabras_claves($descripcion){
	
		$sql="INSERT INTO palabras_claves
						(
							descripcion						) 
			   VALUES (
			   			'".sanar_cadena($descripcion)."'
			   );";
		//return $sql;	   
		// Ejecuto el primer query
		$this->rs = $this->procesarQuery2($sql);
		return $this->rs;

	}
}	
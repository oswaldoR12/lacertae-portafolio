<?php
require_once("../modelos/palabrasclavesModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
		case 'registrar_palabras_claves':
			registrar_palabras_claves($arreglo_datos);
			break;	
		case 'modificar_palabras_claves':
			modificar_palabras_claves($arreglo_datos);
			break;
		case 'consultar_palabras_claves':
			consultar_palabras_claves();
			break;
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	if(isset($data->descripcion))
		$user_data["descripcion"] = $data->descripcion;
	else
		$user_data["descripcion"] = "";

	return $user_data;
}
//------------------------------------------------------
function registrar_palabras_claves($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto = new palabrasclavesModel();
	//reguistro la marca
	$palabras = $arreglo_datos["descripcion"];
	$arreglo_palabras = explode(",", $palabras);
	foreach ($arreglo_palabras as $value) {
		//--------------------------------------
		$recordset = $objeto->registrar_palabras_claves($value);
		//die($recordset);
		if($recordset != 1){
			$mensajes["error"] = "error";
			die(json_encode($mensajes));
		}	
		//--------------------------------------
	}
	$mensajes["mensajes"] = "registro_procesado"; 
	die(json_encode($mensajes));
}
//----------------------------------
function modificar_palabras_claves($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto = new palabrasclavesModel();

	$recordset = $objeto->modificar_palabras_claves($arreglo_datos["descripcion"]);
	if($recordset ==1){
		$mensajes["mensajes"] = "modificacion_procesada";
	}else{
		$mensajes["error"] = "error";
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------

function consultar_palabras_claves(){
	$recordset = array();
	$mensajes = array();
	$objeto = new palabrasclavesModel();
	$recordset = $objeto->consultar_palabras_claves();
	$i = 0;
	$soportes = "";
 
	foreach ($recordset as $campo) {
		$a = $i+1;
		$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"number"=>$a);
		$i++;
		$id_soportes = "";
	}
	die(json_encode($mensajes));
}
//-----------------------------------------------------
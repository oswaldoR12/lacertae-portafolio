<?php
require_once("../modelos/detallesNegociosModel.php");
$objeto = new detallesNegociosModel();
/*if(isset($_GET["delete"]) && $_GET["delete"] == true)
	{
		$name = $_POST["filename"];
		if(file_exists('../site_media/images/archivos/'.$name))
		{
			unlink('../site_media/images/archivos/'.$name);
			$path = '../site_media/images/archivos/'.$name;
			$recordset = $objeto_imagen->eliminar_imagen($path);
			echo json_encode(array("res" => true));
		}
		else
		{
			echo json_encode(array("res" => false));
		}
	}
	else
	{*/
	//var_dump($_POST);
	if($_POST){
		//----------------------------------------------------
		$file = $_FILES["file"]["name"];
		$filetype = $_FILES["file"]["type"];
		$filesize = $_FILES["file"]["size"];
		$id_negocio = $_POST["id_negocio"];
		$tipo = explode("/", $filetype);
		//echo $filetype;
		//---
		//Valido el tipo de archivo...
		if(($tipo[1]=="msword")||($tipo[1]=="doc")||($tipo[1]=="pdf")||($tipo[1]=="docx")||($tipo[1]=="odt")){
		//------------------------------------------------------------		
			//Valido el tamano del archivo
			if($filesize>1000000000){
				die("no_tamano");
			}
			//---
			$nombre_archivo = $_POST["nombre_archivo"].".".$tipo[1];
			$nombre_archivo = str_replace(" ", "_", $nombre_archivo);

			if(!is_dir("../site_media/images/archivos/folletos/"))
			{
				$ruta ="../site_media/images/archivos/folletos/";
				mkdir($ruta, 0777);
			}	
			//die("../site_media/images/archivos/folletos/".$nombre_archivo);
			if($file && move_uploaded_file($_FILES["file"]["tmp_name"], "../site_media/images/archivos/folletos/".$nombre_archivo)){
				$ruta = realpath(dirname(__FILE__));
				$vector_ruta = explode("/controladores", $ruta);
				$ruta_suprema = explode("/html", $vector_ruta[0]);
				$path = "../administrador/site_media/images/archivos/folletos/".$nombre_archivo;
				$recordset = $objeto->modificar_folleto($path,$id_negocio);
				die($recordset);
				//var_dump($recordset);
				/*echo  $directorio;*/
			}
		//--------------------------------------------------------
		}else
		{
			die("error_tipo_archivo");
		}	
	}	
	//}
<?php
require_once("../modelos/categoriasModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){

	switch ($arreglo_datos["accion"]) {
		case 'consultar_categorias':
			consultar_categorias($arreglo_datos);
			break;
		case 'registrar_categorias':
			registrar_categorias($arreglo_datos);
			break;	
		case 'modificar_categorias':
			modificar_categorias($arreglo_datos);
			break;
		case 'modificar_categorias_estatus':
			modificar_categorias_estatus($arreglo_datos);
			break;			 			
	}
}
//------------------------------------------------------
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;

	if(isset($data->id))
		$user_data["id"] = $data->id;
	else
		$user_data["id"] = "";

	if(isset($data->descripcion))
		$user_data["descripcion"] = $data->descripcion;
	else
		$user_data["descripcion"] = "";		
	
	if( isset($data->estatus))
		$user_data["estatus"] = $data->estatus;
	else
		$user_data["estatus"] = "";

	return $user_data;
}
//------------------------------------------------------
function consultar_categorias($arreglo_datos){
	$recordset = array();
	$objeto = new categoriasModel();
	$recordset = $objeto->consultar_categorias("");
	//die($recordset);
	$i = 0;
	foreach ($recordset as $campo) {
		$a = $i+1;
		$categorias[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"number"=>$a,"estatus"=>$campo[2]);
		$i++;
	}
	echo(json_encode($categorias));
}
//------------------------------------------------------
function registrar_categorias($arreglo_datos){
	$recordset = array();
	$objeto = new categoriasModel();
	//Consulto si existe la categoria
	$existe = $objeto->consultar_existe_categorias($arreglo_datos["descripcion"]);
	if($existe[0][0]!="0"){
		$mensajes["mensajes"] = "existe";	
	}else{	
		$recordset_categorias = $objeto->registrar_categorias($arreglo_datos);
		if($recordset_categorias==1){
			$mensajes["mensajes"] = "registro_procesado";
			$id_categorias = $objeto->maximo_id_categorias();
			$mensajes["id_categorias"] = $id_categorias[0][0];
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//-------------------------------------------------------
function modificar_categorias_estatus($arreglo_datos){
	$recordset = array();
	$objeto = new categoriasModel();
	$existe = $objeto->consultar_existe_categorias2($arreglo_datos["id"]);
	//Verifico si existe la categoria
	if($existe[0][0]==0){
		$mensajes["mensaje"] = "no_existe";
	}else{
		if($arreglo_datos["estatus"]==0){
			$arreglo_datos["estatus"] = 1;
		}else{
			$arreglo_datos["estatus"] = 0;
		}
		$recordset = $objeto->modificar_categorias_estatus($arreglo_datos["id"],$arreglo_datos["estatus"]);
		if($recordset==1){
			$mensajes["mensajes"] = "modificacion_procesada"; 
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------
function modificar_categorias($arreglo_datos){
	$recordset = array();
	$objeto_marcas = new categoriasModel();
	$existe_marcas = $objeto_marcas->consultar_existe_categorias2($arreglo_datos["id"]);
	if($existe_marcas[0][0]==0){
		$mensajes["mensajes"] = "no_existe_categoria"; 
	}else{//si existe....
			$recordset_categorias = $objeto_marcas->modificar_categorias($arreglo_datos);
			if($recordset_categorias==1){
				$mensajes["mensajes"] = "modificacion_procesada";
				$mensajes["id_categorias"] = $arreglo_datos["id"];
			}else{
				$mensajes["error"] = "error";
			}
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------
?>
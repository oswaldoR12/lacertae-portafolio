<?php
require_once("../modelos/blogModel.php");
require_once("../modelos/tagsModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
		case 'registrar_blog':
			registrar_blog($arreglo_datos);
			break;
		case 'consultar_blog':
			consultar_blog();
			break;
		case 'actualizar_blog':
			actualizar_blog($arreglo_datos);
			break;	
		case 'modificar_estatus':
			modificar_estatus($arreglo_datos);			
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	//--
	if(isset($data->id))
		$user_data["id"] = $data->id;
	else
		$user_data["id"] = "";

	if(isset($data->titulo))
		$user_data["titulo"] = $data->titulo;
	else
		$user_data["titulo"] = "";

	
	if(isset($data->descripcion))
		$user_data["descripcion"] = $data->descripcion;
	else
		$user_data["descripcion"] = "";

	if(isset($data->id_idioma))
		$user_data["id_idioma"] = $data->id_idioma;
	else
		$user_data["id_idioma"] = "";

	if(isset($data->fecha_publicacion))
		$user_data["fecha_publicacion"] = $data->fecha_publicacion;
	else
		$user_data["fecha_publicacion"] = "";

	if(isset($data->tags))
		$user_data["tags"] = $data->tags;
	else
		$user_data["tags"] = "";

	if(isset($data->id_imagen))
		$user_data["id_imagen"] = $data->id_imagen;
	else
		$user_data["id_imagen"] = "";

	if( isset($data->estatus))
		$user_data["estatus"] = $data->estatus;
	else
		$user_data["estatus"] = "";
	return $user_data;
}
//------------------------------------------------------
function registrar_blog($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto_blog = new blogModel();
	//Consulto si existe un blog con ese titulo:
	$existe = $objeto_blog->consultar_existe($arreglo_datos["titulo"],$arreglo_datos["id_idioma"]);
	if($existe[0][0]>0){
		$mensajes["mensajes"] = "existe_blog";
	}else{
		$recordset_blog = $objeto_blog->registrar_blog($arreglo_datos);
		//die($recordset_blog);
		if($recordset_blog ==1){
			$mensajes["mensajes"] = "registro_procesado";
			$id_blog = $objeto_blog->maximo_id_blog();
			$mensajes["id_blog"] = $id_blog[0][0];
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//----------------------------------
function consultar_blog(){
	$recordset = array();
	$mensajes = array();
	$objeto = new blogModel();
	$objeto2 = new tagsModel();
	$recordset = $objeto->consultar_blog();
	//die($recordset);
	$i = 0;
	$soportes = "";
	foreach ($recordset as $campo) {
		//$fecha = new DateTime($campo[5]);
		$vector_fecha = explode("-", $campo[5]);
		$fecha = $vector_fecha[2]."/".$vector_fecha[1]."/".$vector_fecha[0];
		$a = $i+1;
		$sin_html = strip_tags($campo[3]);
		$descripcion_corta = substr($sin_html,0,200)."...";

		$lista_tags = $objeto2->consultar_tag_blog($campo[0]);

		$arreglo_idioma = array("id"=>$campo[10],"descripcion"=>$campo[11]);	

		$mensajes[] = array("id"=>$campo[0],"titulo"=>$campo[6],"imagen"=>$campo[12],"descripcion"=>$campo[3],"id_imagen"=>$campo[1],"estatus"=>$campo[4],"fecha_publicacion"=>$fecha,"number"=>$a,"descripcion_corta"=>$descripcion_corta,"id_usuario"=>$campo[7],"nombre_usuario"=>$campo[8],"idioma"=>$arreglo_idioma,"archivo"=>$campo[2],"tags"=>$lista_tags,"consulta"=>"");
		$i++;
	}
	die(json_encode($mensajes));
}
//----------------------------------
function actualizar_blog($arreglo_datos){
	$recordset = array();
	$mensajes = array();
	$objeto_blog = new blogModel();
	$existe = $objeto_blog->consultar_existe2($arreglo_datos["id"]);
	if($existe[0][0]==0){
		$mensajes["mensajes"] = "no_existe_blog";
	}else{
		$existe2= $objeto_blog->consultar_existe_otro($arreglo_datos["titulo"],$arreglo_datos["id"],$arreglo_datos["id_idioma"]);
		if($existe2[0][0]>0){
			$mensajes["mensajes"] = "existe_blog";
		}else{
			//Si no existe un blog con ese nombre y distinto id
			$recordset_blog = $objeto_blog->modificar_blog($arreglo_datos);
			if($recordset_blog==1){
				$mensajes["mensajes"] = "modificacion_procesada";
			}else{
				$mensajes["error"] = "error";
			}
		}
	}
	die(json_encode($mensajes));
}
//----------------------------------
function modificar_estatus($arreglo_datos){
	$recordset = array();
	$objeto = new blogModel();
	$existe = $objeto->consultar_existe2($arreglo_datos["id"]);
	//die($existe);
	//Verifico si existe la imagen
	if($existe[0][0]==0){
		$mensajes["mensaje"] = "no_existe";
	}else{
		if($arreglo_datos["estatus"]==0){
			$arreglo_datos["estatus"] = 1;
		}else{
			$arreglo_datos["estatus"] = 0;
		}
		$recordset = $objeto->modificar_blog_estatus($arreglo_datos["id"],$arreglo_datos["estatus"]);
		if($recordset==1){
			$mensajes["mensajes"] = "modificacion_procesada"; 
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//----------------------------------
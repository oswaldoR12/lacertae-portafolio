<?php
require_once("../modelos/tagsModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
		case 'registrar_tags':
			registrar_tags($arreglo_datos);
			break;	
		case 'modificar_tags':
			modificar_tags($arreglo_datos);
			break;
		case 'modificar_estatus':
			modificar_estatus($arreglo_datos);
			break;	
		case 'consultar_tags':
			consultar_tags();
			break;
		case 'consultar_tags2':
			consultar_tags2($arreglo_datos);	
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	if(isset($data->descripcion))
		$user_data["descripcion"] = $data->descripcion;
	else
		$user_data["descripcion"] = "";

	if( isset($data->id))
		$user_data["id"] = $data->id;
	else
		$user_data["id"] = "";
	
	if( isset($data->id_idioma))
		$user_data["id_idioma"] = $data->id_idioma;
	else
		$user_data["id_idioma"] = "";
	
	if( isset($data->estatus))
		$user_data["estatus"] = $data->estatus;
	else
		$user_data["estatus"] = "";
	return $user_data;
}
//------------------------------------------------------
function registrar_tags($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto = new tagsModel();
	//reguistro tags
	$existe_tags = $objeto->consultar_existe_tags($arreglo_datos["descripcion"]);
	if($existe_tags[0][0]>0){
		$mensajes["mensajes"] = "existe"; 
	}else{//no existe....
		$recordset_tags = $objeto->registrar_tags($arreglo_datos);
		if($recordset_tags==1){
			$mensajes["mensajes"] = "registro_procesado";
			$id_tags = $objeto->maximo_id_tags();
			$mensajes["id_tags"] = $id_tags[0][0];
		}else{
			$mensajes["error"] = "error";
		}
	}	
	die(json_encode($mensajes));
}
//----------------------------------
function modificar_tags($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto_marcas = new tagsModel();
	$existe_marcas = $objeto_marcas->consultar_existe_tags2($arreglo_datos["id"]);
	if($existe_marcas[0][0]==0){
		$mensajes["mensajes"] = "no_existe"; 
	}else{//si existe....

		$recordset = $objeto_marcas->modificar_tags($arreglo_datos);
		if($recordset ==1){
			$mensajes["mensajes"] = "modificacion_procesada";
			$mensajes["id_marca"] = $arreglo_datos["id"];
		}else{
			$mensajes["error"] = "error";
		}
	}
	//-----------------------------------
	die(json_encode($mensajes));
	//-----------------------------------
}
//---------------------------------------------------
function modificar_estatus($arreglo_datos){ 
	$recordset = array();
	$objeto = new tagsModel();
	$existe = $objeto->consultar_existe_tags2($arreglo_datos["id"]);
	//Verifico si existe la empresa
	if($existe[0][0]==0){
		$mensajes["mensaje"] = "no_existe";
	}else{
		if($arreglo_datos["estatus"]==0){
			$arreglo_datos["estatus"] = 1;
		}else{
			$arreglo_datos["estatus"] = 0;
		}
		$recordset = $objeto->modificar_tags_estatus($arreglo_datos["id"],$arreglo_datos["estatus"]);
		if($recordset==1){
			$mensajes["mensajes"] = "modificacion_procesada"; 
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------
function consultar_tags(){
	$recordset = array();
	$mensajes = array();
	$objeto = new tagsModel();
	$recordset = $objeto->consultar_tags("");
	$i = 0;
	$soportes = "";
	foreach ($recordset as $campo) {
		$a = $i+1;

		$arreglo_idioma = array("id"=>$campo[2],"descripcion"=>$campo[4]);

		$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"marcas_soportes"=>$soportes,"number"=>$a,"idioma"=>$arreglo_idioma,"id_idioma"=>$campo[2],"estatus"=>$campo[3]);
		$i++;
	}
	die(json_encode($mensajes));
}
//-----------------------------------------------------
//Para consultas en select
function consultar_tags2($arreglo_datos){
	$recordset = array();
	$mensajes = array();
	$objeto = new tagsModel();
	$recordset = $objeto->consultar_tags($arreglo_datos["id_idioma"]);
	//die($recordset);
	$i = 0;
	$soportes = "";
	foreach ($recordset as $campo) {
	//--	
		if($campo[3]==1){
		//--	
			$a = $i+1;
			$arreglo_idioma = array("id"=>$campo[2],"descripcion"=>$campo[4]);
			$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"marcas_soportes"=>$soportes,"number"=>$a,"idioma"=>$arreglo_idioma,"id_idioma"=>$campo[2],"estatus"=>$campo[3]);
			$i++;
		//--	
		}
	//--	
	}
	die(json_encode($mensajes));
}
//-----------------------------------------------------
<?php
require_once("../modelos/categoriasalbumModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
		case 'registrar_categorias':
			registrar_categorias($arreglo_datos);
			break;	
		case 'modificar_categorias':
			modificar_categorias($arreglo_datos);
			break;
		case 'modificar_estatus':
			modificar_estatus($arreglo_datos);
			break;	
		case 'consultar_categoriass':
			consultar_categoriass();
			break;
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	if(isset($data->descripcion))
		$user_data["descripcion"] = $data->descripcion;
	else
		$user_data["descripcion"] = "";		
	
	if( isset($data->estatus))
		$user_data["estatus"] = $data->estatus;
	else
		$user_data["estatus"] = "";
	return $user_data;
}
//------------------------------------------------------
function registrar_categorias($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto = new categoriasalbumModel();
	//Consulto si existe la categoria
	$existe = $objeto->consultar_existe_categorias($arreglo_datos["descripcion"])
	
	//registro la categorias
	$recordset_categorias = $objeto->registrar_categorias($arreglo_datos);
	die($recordset_categorias);
	if($recordset_categorias==1){
		$mensajes["mensajes"] = "registro_procesado";
		$id_categorias = $objeto->maximo_id_categorias();
		$mensajes["id_categorias"] = $id_categorias[0][0];
	}else{
		$mensajes["error"] = "error";
	}
	die(json_encode($mensajes));
}
//-------------------------------------------------------
//-------------------------------------------------------
function modificar_categorias($arreglo_datos){
	//------------------------------------
	$recordset = array();
	$objeto_categoriass = new categoriassModel();
	$existe_categoriass = $objeto_categoriass->consultar_existe_categoriass2($arreglo_datos["id"]);
	if($existe_categoriass[0][0]==0){
		$mensajes["mensajes"] = "no_existe_categorias"; 
	}else{//si existe....

		$recordset_categorias = $objeto_categoriass->modificar_categorias($arreglo_datos);
		if($recordset_categorias==1){
			$mensajes["mensajes"] = "modificacion_procesada";
			$mensajes["id_categorias"] = $arreglo_datos["id"];
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------
function modificar_estatus($arreglo_datos){
	$recordset = array();
	$objeto = new categoriassModel();
	$existe = $objeto->consultar_existe_categoriass2($arreglo_datos["id"]);
	//Verifico si existe la empresa
	if($existe[0][0]==0){
		$mensajes["mensaje"] = "no_existe";
	}else{
		if($arreglo_datos["estatus"]==0){
			$arreglo_datos["estatus"] = 1;
		}else{
			$arreglo_datos["estatus"] = 0;
		}
		$recordset = $objeto->modificar_categorias_estatus($arreglo_datos["id"],$arreglo_datos["estatus"]);
		if($recordset==1){
			$mensajes["mensajes"] = "modificacion_procesada"; 
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//---------------------------------------------------
function consultar_categorias(){
	$recordset = array();
	$mensajes = array();
	$objeto = new categoriassModel();
	$recordset = $objeto->consultar_categorias();
	$i = 0;
	$soportes = "";
        $id_soportes = "";
	foreach ($recordset as $campo) {
		$a = $i+1;
		$record_soportes = $objeto->consulta_soportes_categoriass($campo[0]);
		$x = 0;
		$soportes = "";
		foreach ($record_soportes as $campo2) {
			if ($x==0){
				$soportes.=$campo2[0];
				$id_soportes.=$campo2[1];	
			}else{
				$soportes.="|".$campo2[0];
				$id_soportes.="|".$campo2[1];	
			}
			$x++;
		}
		$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"categoriass_soportes"=>$soportes,"id_soportes"=>$id_soportes,"number"=>$a);
		$i++;
		$id_soportes = "";
	}
	die(json_encode($mensajes));
}
//-----------------------------------------------------
function consultar_categoriass(){
	$recordset = array();
	$mensajes = array();
	$objeto = new categoriassModel();
	$recordset = $objeto->consultar_categorias();
	$i = 0;
	$soportes = "";
        $id_soportes = "";
	foreach ($recordset as $campo) {
		$a = $i+1;
		$record_soportes = $objeto->consulta_soportes_categoriass($campo[0]);
		$x = 0;
		$soportes = "";
		foreach ($record_soportes as $campo2) {
			if ($x==0){
				$soportes.=$campo2[0];
				$id_soportes.=$campo2[1];	
			}else{
				$soportes.="|".$campo2[0];
				$id_soportes.="|".$campo2[1];	
			}
			$x++;
		}
		$arreglo_idioma = array("id"=>$campo[2],"descripcion"=>$campo[4]);

		$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"descripcion_sh"=>strip_tags($campo[1]),"id_idioma"=>$campo[2],"estatus"=>$campo[3],"categoriass_soportes"=>$soportes,"id_soportes"=>$id_soportes,"idioma"=>$arreglo_idioma,"number"=>$a);
		$i++;
		$id_soportes = "";
	}
	die(json_encode($mensajes));
} 
//-----------------------------------------------------
<?php
require_once("../modelos/footerModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
		case 'registrar_footer':
			registrar_footer($arreglo_datos);
			break;
		case 'consultar_footer':
			consultar_footer();
			break;	
		case 'modificar_footer':
			modificar_footer($arreglo_datos);
			break;		
		case 'modificar_estatus':
			modificar_estatus($arreglo_datos);
			break;				
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	
	if(isset($data->id))
		$user_data["id"] = $data->id;
	else
		$user_data["id"] = "";

	if (isset($data->descripcion)){
		$user_data["descripcion"] = $data->descripcion;	
	}else{
		$user_data["descripcion"] = "";
	}

	if (isset($data->correo)){
		$user_data["correo"] = $data->correo;	
	}else{
		$user_data["correo"] = "";
	}

	if (isset($data->rif)){
		$user_data["rif"] = $data->rif;	
	}else{
		$user_data["rif"] = "";
	}

	if (isset($data->id_idioma)){
		$user_data["id_idioma"] = $data->id_idioma;	
	}else{
		$user_data["id_idioma"] = "";
	}

	if (isset($data->estatus)){
		$user_data["estatus"] = $data->estatus;	
	}else{
		$user_data["estatus"] = "";
	}
		
	
	return $user_data;
}
//------------------------------------------------------
function registrar_footer($arreglo_datos){
	//var_dump($arreglo_datos);
	//------------------------------------
	$recordset = array();
	$objeto = new footerModel();
	$recordset = $objeto->registrar_footer($arreglo_datos);
	if($recordset==1){
		$mensajes["mensajes"] = "registro_procesado";
		$id_footer = $objeto->maximo_id_footer();
		$mensajes["id"] = $id_footer[0][0];
		$id_footer = $id_footer[0][0];
		//----------------------------------------------------
		die(json_encode($mensajes));
	}else{
		$recordset[0][0]="error";
		die(json_encode($recordset));
	}
	//die(json_encode($recordset));	
}
//-------------------------------------------------------
function modificar_footer($arreglo_datos){
	//var_dump($arreglo_datos);
	//------------------------------------
	$recordset = array();
	$objeto = new footerModel();
	$existe = $objeto->existe_footer($arreglo_datos["id"]);
	if($existe[0][0]>0){
		//---
		$recordset = $objeto->modificar_footer($arreglo_datos);
		if($recordset==1){
			//Elimino los telefonos
			$id_direccion = $arreglo_datos["id"];
			$mensajes["mensajes"] = "modificacion_procesada";
		}else{
			$mensajes["mensajes"] = "error";
		}	
		//---
	}else{
		$mensajes["mensajes"] = "no_existe";
	}
	die(json_encode($mensajes));
	//die(json_encode($recordset));	
}
//-------------------------------------------------------
function modificar_estatus($arreglo_datos){
	$recordset = array();
	$objeto = new footerModel();
	$existe = $objeto->existe_footer($arreglo_datos["id"]);
	//Verifico si existe la imagen
	if($existe[0][0]==0){
		$mensajes["mensaje"] = "no_existe";
	}else{
		if($arreglo_datos["estatus"]==0){
			$arreglo_datos["estatus"] = 1;
		}else{
			$arreglo_datos["estatus"] = 0;
		}
		$recordset = $objeto->modificar_footer_estatus($arreglo_datos["id"],$arreglo_datos["estatus"]);
		//die($recordset);
		if($recordset==1){
			$mensajes["mensajes"] = "modificacion_procesada"; 
		}else{
			$mensajes["error"] = "error";
		}
	}
	die(json_encode($mensajes));
}
//-------------------------------------------------------
function consultar_footer(){
	$recordset = array();
	$mensajes = array();
	$objeto = new footerModel();
	$recordset = $objeto->consultar_footer();
	$i = 0;
	foreach ($recordset as $campo) {
		//$fecha = new DateTime($campo[5]);
		$a = $i+1;
		$arreglo_idioma = array("id"=>$campo[4],"descripcion"=>$campo[5]);
		$mensajes[] = array("id"=>$campo[0],"descripcion"=>$campo[1],"correo"=>$campo[2],"rif"=>$campo[3],"number"=>$a,"id_idioma"=>$campo[4],"idioma"=>$arreglo_idioma,"estatus"=>$campo[6]);
		$i++;
	}
	die(json_encode($mensajes));
}
//-------------------------------------------------------

<?php
require_once("../modelos/categoriasModel.php");
require_once("../modelos/galeriaModel.php");
$objeto_imagen = new galeriaModel();
$objeto = new categoriasModel();
	
	/*if(isset($_GET["delete"]) && $_GET["delete"] == true)
	{
		$name = $_POST["filename"];
		if(file_exists('../site_media/images/archivos/'.$name))
		{
			unlink('../site_media/images/archivos/'.$name);
			$path = '../site_media/images/archivos/'.$name;
			$recordset = $objeto_imagen->eliminar_imagen($path);
			echo json_encode(array("res" => true));
		}
		else
		{
			echo json_encode(array("res" => false));
		}
	}
	else
	{*/
	//var_dump($_POST);
	if($_POST){
		//----------------------------------------------------
		$file = $_FILES["file"]["name"];
		$filetype = $_FILES["file"]["type"];
		$filesize = $_FILES["file"]["size"];
		$id_categoria = $_POST["categoria"];
		$tipo = explode("/", $filetype);
		$nombre_archivo = $_POST["nombre_archivo"].".".$tipo[1];
		$recordset = $objeto->consultar_categorias($id_categoria);
		$categoria = $recordset[0][1];
		if(!is_dir("../site_media/images/archivos/".$categoria."/"))
		{
			$ruta ="../site_media/images/archivos/".$categoria."/";
			mkdir($ruta, 0777);
		}	

		if($file && move_uploaded_file($_FILES["file"]["tmp_name"], "../site_media/images/archivos/".$categoria."/".$nombre_archivo))
		{
			$ruta = realpath(dirname(__FILE__));
			$vector_ruta = explode("/controladores", $ruta);
			$ruta_suprema = explode("/html", $vector_ruta[0]);
			$path = "../administrador/site_media/images/archivos/".$categoria."/".$nombre_archivo;
			$recordset = $objeto_imagen->registrar_imagen($path,$id_categoria);
			var_dump($recordset);
			echo  $directorio;
		}
		//--------------------------------------------------------
	}	
		
	//}

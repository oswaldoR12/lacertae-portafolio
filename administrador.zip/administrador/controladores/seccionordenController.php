<?php
require_once("../modelos/seccionnoticiasModel.php");
require_once("../core/fbasic.php");
//--Declaraciones
$mensajes = array();
//--Recibo lo enviado por POST
$data = json_decode(file_get_contents("php://input"));

$post = helper_userdata($data);
redireccionar_metodos($post);
//--
function redireccionar_metodos($arreglo_datos){
	switch ($arreglo_datos["accion"]) {
			
		case 'consultar_precio':
			consultar_precio($arreglo_datos);
			break;	
		case 'registrar_orden':
			registrar_orden($arreglo_datos);
			break;		
	}	
}
//---
function helper_userdata($data){
	$user_data = array();
	$user_data["accion"] = $data->accion;
	if(isset($data->id))
		$user_data["id"] = $data->id;
	else
		$user_data["id"] = 	"";

	if(isset($data->tipo_documento))
		$user_data["tipo_documento"] = $data->tipo_documento;
	else 
		$user_data["tipo_documento"] = "";

	if(isset($data->nro_documento))
		$user_data["nro_documento"] = $data->nro_documento;
	else
		$user_data["nro_documento"] = "";

	if(isset($data->nombre))
		$user_data["nombre"] = $data->nombre;
	else
		$user_data["nombre"] = "";

	if( isset($data->telefono))
		$user_data["telefono"] = $data->telefono;
	else
		$user_data["telefono"] = "";

	if( isset($data->correo))
		$user_data["correo"] = $data->correo;
	else
		$user_data["correo"] = "";
	
		if( isset($data->peso))
		$user_data["peso"] = $data->peso;
	else
		$user_data["peso"] = "";
	
		if( isset($data->altura))
		$user_data["altura"] = $data->altura;
	else
		$user_data["altura"] = "";
	
		if( isset($data->ancho))
		$user_data["ancho"] = $data->ancho;
	else
		$user_data["ancho"] = "";
	
		if( isset($data->largo))
		$user_data["largo"] = $data->largo;
	else
		$user_data["largo"] = "";
	
		if( isset($data->origen))
		$user_data["origen"] = $data->origen;
	else
		$user_data["origen"] = "";
	
	if( isset($data->destino))
		$user_data["destino"] = $data->destino;
	else
		$user_data["destino"] = "";

	if( isset($data->kilometraje))
		$user_data["kilometraje"] = $data->kilometraje;
	else
		$user_data["kilometraje"] = "";

	if( isset($data->precio))
		$user_data["precio"] = $data->precio;
	else
		$user_data["precio"] = "";
	
	if(isset($data->estatus))
		$user_data["estatus"] = $data->estatus;
	else
		$user_data["estatus"] = "";
	return $user_data;
}
//---
//------------------------------------------------------


function consultar_precio($arreglo_datos){
	
	
	$url = "https://test.menssajero.com/api/logistica-orden/create/v1";
    $curl = curl_init();
    $header = array(
        'Authorization:Bearer 10|MUkkpYfjgLkifdfT13mWGeBcaw4a1wU4z4qeiPWy',
        "Accept: application/json",
        "Content-Type: application/json",
    );
    $fields = array(
        'direccion_origen'  => $arreglo_datos['origen'],
        'direccion_destino' => $arreglo_datos['destino'],
        'kilometraje'       => $arreglo_datos['kilometraje'],

        'nombre_destinatario'           => "PRUEBA",
        'tipo_documento_destinatario'   => $arreglo_datos['tipo_documento'],
        'numero_documento_destinatario' => $arreglo_datos['nro_documento'],
        'correo_destinatario'           => $arreglo_datos['correo'],
        'telefono_destinatario'         => $arreglo_datos['telefono'],

        'peso_en_kilo' => $arreglo_datos['peso'],
        'alto'         => $arreglo_datos['altura'],
        'ancho'        => $arreglo_datos['ancho'],
        'largo'        => $arreglo_datos['largo'],
        'precio'       => '0',
        'descripcion'  => 'Pruebas',
        'consulta'  => true,

    );
    $json_string = json_encode($fields);

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json_string);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

    //Ejecutar la solicitud de cURL
    $data = curl_exec($curl);

    //cerramos la sesión de cURL
    curl_close($curl);

    //decodificar la información y declarar variable
    $datos= json_decode($data);

	$mensajes["mensajes"] = "registro_procesado";
	$mensajes["precio"] = $datos->costo_del_envio;

	
	die(json_encode($mensajes));
}
//--
//------------------------------------------------------
function registrar_orden($arreglo_datos){
	//------------------------------------

	$recordset = array();
	$objeto = new seccionnoticiasModel();

	$url = "https://test.menssajero.com/api/logistica-orden/create/v1";
    $curl = curl_init();
    $header = array(
        'Authorization:Bearer 10|MUkkpYfjgLkifdfT13mWGeBcaw4a1wU4z4qeiPWy',
        "Accept: application/json",
        "Content-Type: application/json",
    );
    $fields = array(
        'direccion_origen'  => $arreglo_datos['origen'],
        'direccion_destino' => $arreglo_datos['destino'],
        'kilometraje'       => $arreglo_datos['kilometraje'],
        'nombre_destinatario'           => $arreglo_datos['nombre'],
        'tipo_documento_destinatario'   => $arreglo_datos['tipo_documento'],
        'numero_documento_destinatario' => $arreglo_datos['nro_documento'],
        'correo_destinatario'           => $arreglo_datos['correo'],
        'telefono_destinatario'         => $arreglo_datos['telefono'],
        'peso_en_kilo' => $arreglo_datos['peso'],
        'alto'         => $arreglo_datos['altura'],
        'ancho'        => $arreglo_datos['ancho'],
        'largo'        => $arreglo_datos['largo'],
        'precio'       => '0',
        'descripcion'  => 'Pruebas',
        'consulta'  => false,
    );
    $json_string = json_encode($fields);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json_string);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    //Ejecutar la solicitud de cURL
    $data = curl_exec($curl);
    //cerramos la sesión de cURL
    curl_close($curl);
    //decodificar la información y declarar variable
    $datos= json_decode($data);

	//no existe, guardo
	$recordset = $objeto->registrar_noticias($arreglo_datos,$datos->numero_orden);
	//die($recordset);
	if($recordset==1){
		$mensajes["mensajes"] = "registro_procesado";
		$id_imagen = $objeto->maximo_id_noticias();
		$mensajes["id"] = $id_imagen[0][0];
	}else{
		$mensajes["mensajes"] = "error";
	}

	die(json_encode($mensajes));
	//--
}	